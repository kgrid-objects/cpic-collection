function genophenokolist(inputs){
  var list ={}
  for (var key in inputs){
    list[key]=kolist[key]
  }
  return list;
}

var kolist={"CFTR": "","CYP2C19":"/99999/fk4mc97w0h/v0.0.4", "CYP2C9" :"/99999/fk4bv8qb3r/v0.0.1","CYP2D6": "/99999/fk49z9gr7p/v0.0.6","CYP3A5": "/99999/fk4md04x9z/v0.0.1","CYP4F2": "","DPYD": "","G6PD": "", "HLA-A" : "", "HLA-B" : "",  "IFNL3" : "", "SLCO1B1" : "/99999/fk47380j09/v0.0.1", "TPMT" : "/99999/fk4vq45s09/v0.0.1",  "UGT1A1": "/99999/fk47h1x090/v0.0.4",  "VKORC1" : "",  }
